mahasiswa = ("A001", "Budi", "Informatika")
#tampilkan nama
print(mahasiswa[1])
#tampilkan semua isi
for x in mahasiswa:
    print(x)

'''
karena kegunaan tuple adalah sebagi tipe data dan tempat meyimpan data yang efisien
dan tidak sama dengan list
'''